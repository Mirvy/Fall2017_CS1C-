var searchData=
[
  ['text',['Text',['../class_shape_1_1_text.html',1,'Shape']]]
];
