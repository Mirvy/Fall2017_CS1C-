var searchData=
[
  ['ellipse',['Ellipse',['../class_shape_1_1_ellipse.html',1,'Shape']]]
];
