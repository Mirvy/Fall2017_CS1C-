var searchData=
[
  ['rectangle',['Rectangle',['../class_shape_1_1_rectangle.html',1,'Shape']]],
  ['resize',['resize',['../classmy_std_1_1vector.html#aa54bd9c3d8d3b6191d7eb7f85490eadb',1,'myStd::vector']]]
];
