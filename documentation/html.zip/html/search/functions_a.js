var searchData=
[
  ['setbrush',['setBrush',['../class_shape_1_1_shape.html#aa7984be5f5683269a542c6066aba1693',1,'Shape::Shape']]],
  ['setfont',['setFont',['../class_shape_1_1_shape.html#a0bcae2b172faacd92e58dc1004a29754',1,'Shape::Shape::setFont()'],['../class_shape_1_1_text.html#ab9e53ca842be0b46549c9d1ca8973e41',1,'Shape::Text::setFont()']]],
  ['setheight',['setHeight',['../class_shape_1_1_rectangle.html#aedc754887ca6db3a0ff035f66f919a38',1,'Shape::Rectangle']]],
  ['setid',['setId',['../class_shape_1_1_shape.html#a8ee5c12db1ac20ab5e5cb91a1e840cfb',1,'Shape::Shape']]],
  ['setorigin',['setOrigin',['../class_shape_1_1_ellipse.html#a4d3b48d67f3d2dfb7a7bc2411a3a3c05',1,'Shape::Ellipse']]],
  ['setpen',['setPen',['../class_shape_1_1_shape.html#af6fa70957983a4b4af6e67c5f3d3b438',1,'Shape::Shape']]],
  ['setrx',['setRx',['../class_shape_1_1_ellipse.html#a43507f9fef37e23504a7cb37c19056f0',1,'Shape::Ellipse']]],
  ['setry',['setRy',['../class_shape_1_1_ellipse.html#ab29b5d66f6bc6a9f0e834051d8910829',1,'Shape::Ellipse']]],
  ['setshape',['setShape',['../classcanvas.html#a38495ed4a02b31154445c112d2f76572',1,'canvas::setShape()'],['../class_shape_1_1_shape.html#a919592de4ad6981f2b2bfa2afb81c815',1,'Shape::Shape::setShape()']]],
  ['settext',['setText',['../class_shape_1_1_shape.html#aaeb53221cf0546e8968b5ec4314ca549',1,'Shape::Shape::setText()'],['../class_shape_1_1_text.html#aefe57ef173b66bea72d42febe671722e',1,'Shape::Text::setText()']]],
  ['setupperleft',['setUpperLeft',['../class_shape_1_1_rectangle.html#a27843e80d9b646e72d1e46b2dce38faf',1,'Shape::Rectangle']]],
  ['setwidth',['setWidth',['../class_shape_1_1_rectangle.html#a74f4aa3d0b11bb1afba74fc4b5f94acb',1,'Shape::Rectangle']]],
  ['shape',['Shape',['../class_shape_1_1_shape.html#ae8f09de0a08acfedbbfd4642d884e2fc',1,'Shape::Shape']]]
];
